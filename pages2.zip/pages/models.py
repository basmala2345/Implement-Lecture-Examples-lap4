from django.db import models

# Create your models here.
image = models.ImageField(upload_to="products/", null=True, blank=True)
