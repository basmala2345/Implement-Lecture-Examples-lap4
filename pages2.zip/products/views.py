from decimal import Decimal, InvalidOperation
from django.shortcuts import render, get_object_or_404
from .models import Product


def product_list(request):
    qs = Product.objects.all()

    # ------------ بحث بالاسم ------------
    # match = contains (افتراضي) أو exact
    q = request.GET.get("q")
    match = request.GET.get("match", "contains")
    if q:
        if match == "exact":
            qs = qs.filter(name__iexact=q)   # exact per PDF
        else:
            qs = qs.filter(name__icontains=q)  # contains per PDF

    # ------------ فلترة بالسعر ------------
    # exact = سعر مساوي لقيمة معينة
    price_exact = request.GET.get("price_exact")
    if price_exact:
        try:
            qs = qs.filter(price=Decimal(price_exact))  # exact
        except InvalidOperation:
            pass

    # in = قائمة أسعار مفصولة بفواصل (مثال: 100,200,1000)
    prices_in = request.GET.get("prices_in")
    if prices_in:
        try:
            values = [Decimal(p.strip()) for p in prices_in.split(",") if p.strip() != ""]
            if values:
                qs = qs.filter(price__in=values)  # in
        except InvalidOperation:
            pass

    # range = من/إلى
    min_price = request.GET.get("min_price")
    max_price = request.GET.get("max_price")
    if min_price:
        try:
            qs = qs.filter(price__gte=Decimal(min_price))  # range lower
        except InvalidOperation:
            pass
    if max_price:
        try:
            qs = qs.filter(price__lte=Decimal(max_price))  # range upper
        except InvalidOperation:
            pass

    # ------------ فلترة بالفئة (choices) ------------
    category = request.GET.get("category")
    if category:
        qs = qs.filter(category=category)

    # ------------ فلترة بالتاريخ (release_date) ------------
    date_from = request.GET.get("date_from")  # YYYY-MM-DD
    date_to = request.GET.get("date_to")      # YYYY-MM-DD
    if date_from:
        qs = qs.filter(release_date__gte=date_from)
    if date_to:
        qs = qs.filter(release_date__lte=date_to)

    # ------------ الترتيب ------------
    # أمثلة: -price, price, -name, name, -release_date
    order = request.GET.get("order")
    if order:
        qs = qs.order_by(order)
    else:
        qs = qs.order_by("-price")

    context = {"products": qs}
    return render(request, "products/products.html", context)


def product_detail(request, pk):
    product = get_object_or_404(Product, pk=pk)
    return render(request, "products/detail.html", {"product": product})
